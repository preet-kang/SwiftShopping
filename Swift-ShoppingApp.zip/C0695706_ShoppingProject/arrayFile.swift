
import Foundation
class arrayFile
{
    var image1=""
    var name1=""
    var price1:Int=0
    
    
    var image2=""
    var name2=""
    var price2:Int=0
    
    
    var arrayOfObjects=[arrayFile]()
    
    
    func getArray() -> [arrayFile] {
        let obj1=arrayFile()
        obj1.name1="Computer"
        obj1.image1="dell"
        obj1.price1=750
        obj1.name2="HP Laptop"
        obj1.image2="computer"
        obj1.price2=1050
        arrayOfObjects.append(obj1)
        
        let obj2=arrayFile()
        obj2.name1="Iphone 7 plus"
        obj2.image1="iphone"
        obj2.price1=1200
        obj2.name2="Dell PC"
        obj2.image2="computer"
        obj2.price2=1100
        arrayOfObjects.append(obj2)
        
        let obj3=arrayFile()
        obj3.name1="Samsung 9"
        obj3.image1="glaxy"
        obj3.price1=1200
        obj3.name2="Acer"
        obj3.image2="computer"
        obj3.price2=900
        arrayOfObjects.append(obj3)
        
        let obj4=arrayFile()
        obj4.name1="Galaxy S8"
        obj4.image1="galaxy"
        obj4.price1=1320
        obj4.name2="Mac Book Pro retina display"
        obj4.image2="mac"
        obj4.price2=2600
        arrayOfObjects.append(obj4)
        
        let obj5=arrayFile()
        obj5.name1="one Plus"
        obj5.image1="google"
        obj5.price1=1300
        obj5.name2="Mac Book Air"
        obj5.image2="mac"
        obj5.price2=1500
        arrayOfObjects.append(obj5)
        
        return arrayOfObjects
    }
}
