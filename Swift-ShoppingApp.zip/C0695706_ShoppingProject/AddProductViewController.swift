//
//  AddProductViewController.swift
//  C0695706_ShoppingProject
//
//  Created by Amy kang on 2017-07-27.
//  Copyright © 2017 Amy kang. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
class addProductViewController: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var ref: DatabaseReference!
    @IBOutlet weak var productName: UITextField!
    @IBOutlet weak var productCompany: UITextField!
    @IBOutlet weak var productType: UITextField!
    @IBOutlet weak var productPrice: UITextField!
    @IBOutlet weak var productDescription: UITextField!
   
    @IBOutlet weak var imageView: UIImageView!
    
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        ref = Database.database().reference().child("Products");
        
        // Do any additional setup after loading the view.
    }
    
    
    func selectImage() {
        
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        picker.allowsEditing = true
        present(picker, animated: true, completion: nil)
        
    }
    
    //    3. Func image picker controller
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        imageView.image = info[UIImagePickerControllerEditedImage] as? UIImage
        self.dismiss(animated: true, completion: nil)
        
    }
    

    
    
    
    @IBAction func onClickAdd(_ sender: Any) {
        let pName=productName.text
        let pCompany=productCompany.text
        let pType=productType.text
        let pPrice=productPrice.text
        let pDescription=productDescription.text
        
        let key = ref.childByAutoId().key
        let data = ["id":key,
                    "productName":pName,
                    "productCompany": pCompany,
                    "productType": pType,
                    "productPrice": pPrice,
                    "productDescription": pDescription,
                    "productImage": ""
            
        ]
        ref.child(key).setValue(data)
        print("Added")
        let alertController = UIAlertController(title: "Message", message: "One item added", preferredStyle: .alert)
        
        let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(defaultAction)
        
        self.present(alertController, animated: true, completion: nil)
        
        
        
    }
    @IBAction func onClickFetch(_ sender: Any) {
        self.performSegue(withIdentifier: "toShowProduct", sender: self)
    }

    
    @IBAction func logOOutButtonClicked(_ sender: Any) {
        
        UserDefaults.standard.removeObject(forKey: "usersigned")
        UserDefaults.standard.synchronize()
        
        
        let signUp = self.storyboard?.instantiateViewController(withIdentifier: "SignInViewController") as!  SignInViewController
        
        let delegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        delegate.window?.rootViewController = signUp
        delegate.rememberLogin()
        

        
    }
    
    @IBAction func onClickViewCart(_ sender: Any) {
        //self.performSegue(withIdentifier: "toCart", sender: self)
        let vc = storyboard?.instantiateViewController(withIdentifier: "cartItems1") as! CartItemsVC;
        self.navigationController?.pushViewController(vc, animated: false)
    }

    
    
    @IBAction func shareButtonClicked(_ sender: Any) {
        
        let activityVC = UIActivityViewController(activityItems: ["hello"], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view
        self.present(activityVC, animated: true, completion: nil)
        
        
    }
    
    
    
    @IBAction func contactUs(_ sender: Any) {
        
        let alert = UIAlertController(title: "Contact Us", message: "For more Info", preferredStyle: .actionSheet)
        
        let actionOne = UIAlertAction(title: "Call :- 43728234735", style: .default)
        let actionOne1 = UIAlertAction(title: "E-Mail :- kabadia@ca.in", style: .default)
        { (action) in
            print("Sucess")
        }
        
            alert.addAction(actionOne)
            alert.addAction(actionOne1)
            
            self.present(alert, animated: true, completion: nil)
        
        
    }
    
    
    
    
    
}
