//
//  AddProductViewController.swift
//  C0695706_ShoppingProject
//
//  Created by Amy kang on 2017-07-27.
//  Copyright © 2017 Amy kang. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
class addProductViewController: UIViewController {
    
    var ref: DatabaseReference!
    @IBOutlet weak var productName: UITextField!
    @IBOutlet weak var productCompany: UITextField!
    @IBOutlet weak var productType: UITextField!
    @IBOutlet weak var productPrice: UITextField!
    @IBOutlet weak var productDescription: UITextField!
   
    @IBOutlet weak var imageView: UIImageView!
    
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        ref = Database.database().reference().child("products");
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func onClickAdd(_ sender: Any) {
        var pName=productName.text
        var pCompany=productCompany.text
        var pType=productType.text
        var pPrice=productPrice.text
        var pDescription=productDescription.text
        
        let key = ref.childByAutoId().key
        let data = ["id":key,
                    "productName":pName,
                    "productCompany": pCompany,
                    "productType": pType,
                    "productPrice": pPrice,
                    "productDescription": pDescription,
                    "productImage": ""
            
        ]
        ref.child(key).setValue(data)
        print("Added")
        let alertController = UIAlertController(title: "Message", message: "One item added", preferredStyle: .alert)
        
        let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(defaultAction)
        
        self.present(alertController, animated: true, completion: nil)
        
        
        
    }
    @IBAction func onClickFetch(_ sender: Any) {
        self.performSegue(withIdentifier: "toShowProduct", sender: self)
    }

    
    @IBAction func logOOutButtonClicked(_ sender: Any) {
        
        UserDefaults.standard.removeObject(forKey: "usersigned")
        UserDefaults.standard.synchronize()
        
        
        let signUp = self.storyboard?.instantiateViewController(withIdentifier: "SignInViewController") as!  SignInViewController
        
        let delegate : AppDelegate = UIApplication.shared.delegate as! AppDelegate
        delegate.window?.rootViewController = signUp
        delegate.rememberLogin()
        

        
    }
    
    
    
}
